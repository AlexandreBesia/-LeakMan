var indexSectionsWithContent =
{
  0: "abcdegilmnopqrstuv~",
  1: "abceglmpstv",
  2: "abcdgilmpqrstu~",
  3: "cmnprs",
  4: "at",
  5: "o",
  6: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "enums",
  5: "related",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Enumerations",
  5: "Friends",
  6: "Pages"
};

