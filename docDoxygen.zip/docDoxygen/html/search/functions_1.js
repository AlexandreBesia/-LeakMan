var searchData=
[
  ['block_0',['Block',['../class_block.html#ae2b86c8ec86273fe527a24242d1176bc',1,'Block']]],
  ['boundingrect_1',['boundingRect',['../class_level.html#ac6d07732faf3e90650a454927d7cba88',1,'Level::boundingRect()'],['../class_level_grid.html#a525452788020dfcd96e3e30480c35f92',1,'LevelGrid::boundingRect()']]]
];
