var searchData=
[
  ['name_0',['name',['../struct_block_1_1_type_info.html#a56098caf2e36dbff4fe16258c0f9c8b3',1,'Block::TypeInfo']]]
];
