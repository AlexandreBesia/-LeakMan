var searchData=
[
  ['setnbcamera_0',['setNbCamera',['../class_game_window.html#ac50a98fd0ee307ac639f4fbfc90b1f9b',1,'GameWindow']]],
  ['setsize_1',['setSize',['../class_level_grid.html#a1aef5366a0bdde1a13d8fd65c9ed13b6',1,'LevelGrid']]]
];
