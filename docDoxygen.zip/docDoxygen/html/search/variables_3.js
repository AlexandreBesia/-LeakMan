var searchData=
[
  ['pixmap_0',['pixmap',['../struct_block_1_1_type_info.html#ae375524ae1915cc24d7dd44b659fc61f',1,'Block::TypeInfo']]],
  ['position_1',['position',['../struct_tile.html#a0632e4a29b0caf5bb8925cc6c81df1b8',1,'Tile']]]
];
