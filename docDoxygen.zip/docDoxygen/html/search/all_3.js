var searchData=
[
  ['deserialize_0',['deserialize',['../class_level_grid.html#a531de1f616ceae6e717418019fad9399',1,'LevelGrid']]],
  ['deserializefrom_1',['deserializeFrom',['../class_level.html#afe2a7ceba912c1515a7ce833f3880149',1,'Level']]]
];
