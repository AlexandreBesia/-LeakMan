var searchData=
[
  ['mainwindow_0',['MainWindow',['../class_main_window.html#aeccc930df5863145c179373f5b534162',1,'MainWindow']]]
];
