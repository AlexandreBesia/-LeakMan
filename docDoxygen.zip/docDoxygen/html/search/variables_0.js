var searchData=
[
  ['collidable_0',['collidable',['../struct_block_1_1_type_info.html#a094598416392ca636d359aa29dc27cb7',1,'Block::TypeInfo']]],
  ['column_1',['column',['../struct_tile.html#aafc5e9f3db1b4fb74d2fdb42883243ab',1,'Tile']]]
];
